Inside this folder, there are four main folders. Each are composed of either our arduino code, schematics, PCB/GERBER files, and then enclosure files.
The folders are respectively named to show what they each contain.
In the Arduino Code folder, there is just a single arduino file that has all of our code.
In the PCB Files folder, it contains all of the files that were created for the PCB model on Altium
In the Schematic Files folder, it contains all of the schematics that were used for the Altium design. 
They are also all respectively named for what they contain, though the ATMega file would be primary here
In the enclosure folder, it contains a folder that says Final Stuff which is the finalized enclosure files that we used for the project. 
All of the other files include DXF files for laser cutting, STL for previous designs on the 3D printer.
Some G code is there for the 3D printing, and some files to convert the Altium PCB to a Fusion360 model.